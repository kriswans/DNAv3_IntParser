This is a parser for the DNAv3 DEVNET class.
